let myLinks = [];

function Link() {
}
Link.prototype.pushToArray = function(title) {
    myLinks.unshift(title);
    console.log(myLinks);
}
function addToLibrary(title,location) {
    this.title = title;
    this.location = location;
};
addToLibrary.prototype = Object.create(Link.prototype);

// test businesses for tiles
const Mcdonalds = new addToLibrary('McDonalds','Gold Coast');
const ChickenTreat = new addToLibrary('Chicken Treat','Perth');

Mcdonalds.pushToArray(Mcdonalds);
ChickenTreat.pushToArray(ChickenTreat);

// // check if checkbox is ticked for read
// function checkBox() {    
//     if (document.getElementById('read').checked) {
//         console.log('ticked')
//         return true       
//     }
//     else{
//         return false
//     }
// };

// places remove button on tiles
// function deleteButton (tile, indexi) {
//     let deleteTile = document.createElement('button');
//     deleteTile.setAttribute('class', 'remove');
//     deleteTile.setAttribute('id', indexi);
//     deleteTile.innerHTML = 'Remove';
//     tile.appendChild(deleteTile);
// };

//function to create new tiles
let indexi = 1;
function createLink (title, location) {
    let newLink = new addToLibrary(title, location);
    newLink.pushToArray(newLink);
    let tile = document.createElement('div');
    tile.setAttribute('class', 'tile');
    tile.setAttribute('id', indexi)
    tile.innerHTML = `${title} - ${location}`
//    deleteButton(tile, indexi);
    containerTiles.appendChild(tile); 
    indexi++;
};
// creates the tiles to display the links
const containerTiles = document.getElementById('link-tiles');
myLinks.forEach(function (item) { // adds a tile for each book in array
    let tile = document.createElement('div');
    tile.setAttribute('class', 'tile');
    tile.innerHTML = `${item.title} - ${item.location}`;
    containerTiles.appendChild(tile);
//    deleteButton(tile);
});

// click add new pops up entry form below
const addNew = document.querySelector('#menu');// add new button
addNew.addEventListener('click', () => {
    console.log('popup');
    document.getElementById('form').style.display = 'block';//shows form on click
});

// hides the form by default
document.querySelector('#form').style.display = 'none';

//hides the form when user clicks cancel
const cancel = document.getElementById('cancel');// cancel button
cancel.addEventListener('click', () => {
    console.log('close popup'); 
    document.querySelector('#form').style.display = 'none';// hides form
});

// submit button variable
const subButt = document.getElementById('submit');
subButt.addEventListener('click', () => {
    console.log('submit');
    let titleValue = document.getElementById('title').value;
    let locationValue = document.getElementById('location').value;
    createLink(titleValue, locationValue);
//    console.log(titleValue, locationValue, pageValue, readValue);
})

// // remove button functionality
// const remButt = containerTiles.getElementsByClassName('remove');
// for (let item of remButt) {
//     item.addEventListener('click', () => {
//     console.log(containerTiles.getElementById('indexi'));

// //        
// })}
